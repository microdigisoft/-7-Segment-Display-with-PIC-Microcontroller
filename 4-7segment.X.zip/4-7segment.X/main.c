/*
 * File:   4digitdisplay.c
 * Author: Administrator
 *
 * Created on 23 August, 2020, 9:57 AM
 */

#include < xc.h>
#define _XTAL_FREQ  20000000UL     //  20MHz
// CONFIG1
#pragma config FOSC = HS      // Oscillator Selection (HS Oscillator, High-speed crystal/resonator connected between OSC1 and OSC2 pins)
#pragma config WDTE = OFF       // Watchdog Timer Enable (WDT disabled)
#pragma config PWRTE = OFF      // Power-up Timer Enable (PWRT disabled)
#pragma config MCLRE = ON       // MCLR Pin Function Select (MCLR/VPP pin function is MCLR)
#pragma config CP = OFF         // Flash Program Memory Code Protection (Program memory code protection is disabled)
#pragma config BOREN = ON       // Brown-out Reset Enable (Brown-out Reset enabled)
#pragma config CLKOUTEN = OFF   // Clock Out Enable (CLKOUT function is disabled. I/O or oscillator function on the CLKOUT pin)
#pragma config IESO = ON        // Internal/External Switchover (Internal/External Switchover mode is enabled)
#pragma config FCMEN = ON       // Fail-Safe Clock Monitor Enable (Fail-Safe Clock Monitor is enabled)

// CONFIG2
#pragma config WRT = OFF        // Flash Memory Self-Write Protection (Write protection off)
#pragma config VCAPEN = OFF     // Voltage Regulator Capacitor Enable bit (VCAP pin function disabled)
#pragma config STVREN = ON      // Stack Overflow/Underflow Reset Enable (Stack Overflow or Underflow will cause a Reset)
#pragma config BORV = LO        // Brown-out Reset Voltage Selection (Brown-out Reset Voltage (Vbor), low trip point selected.)
#pragma config LPBOR = OFF      // Low-Power Brown Out Reset (Low-Power BOR is disabled)
#pragma config LVP = OFF         // Low-Voltage Programming Enable (Low-voltage programming enabled)

/*
 *
 */
// This array stores binary bit pattern that will be send to PORTD with Common cathode 7 Segment display
// This array stores binary bit pattern that will be send to PORTD
unsigned char hexvalue[10]= {0x3F,0x06,0x5B,0x4F,0x66,0x6D,0x7D,0x07,0x7F,0x6F};
void main(void) 
{
    int a,b,c,d;
    int i, j;
    PORTCbits.RC0  = 0;  //  First Digit Bit Set as output
    PORTCbits.RC1  = 0;  //  Second Digit Bit Ser as output
    PORTCbits.RC2  = 0;  //  Third Digit Bit Set as output
    PORTCbits.RC3  = 0;  //  Fourth Digit Bit Ser as output
    PORTD     = 0;       //  DATA pin FOR LCD 8bits  port D as output   
    TRISD   = 0;         // Direction for Port D
    TRISCbits.TRISC0= 0;//Set First bit direction
    TRISCbits.TRISC1       = 0; // Set Second bit Direction 
    TRISCbits.TRISC2    = 0;//Set Third bit direction
    TRISCbits.TRISC3       = 0; // Set Fourth bit Direction 
    while(1)
    {
        for (i=0;i<=9999;i++)
{ 
            
           a = i/1000;   // holds 1000's digit
           b = ((i/100)%10); // holds 100's digit
           c = ((i/10)%10);  // holds 10th digit
           d = (i%10);  // holds unit digit value    
for (j = 0; j< 10; j++){
          
PORTD=hexvalue[a]; // send 1000's place data to fourth digit
PORTCbits.RC0=0;   //  turn on forth display unit
__delay_ms(1);
PORTCbits.RC0=1;   //  turn off forth display unit
PORTD=hexvalue[b];  // send 100's place data to 3rd digit
PORTCbits.RC1=0;    //  turn on 3rd display unit
__delay_ms(1);
PORTCbits.RC1=1;  //  turn off 3rd display unit
PORTD=hexvalue[c];  // send 10th place data to 2nd digit
PORTCbits.RC2 = 0;  //  turn on 2nd display unit
__delay_ms(1);
PORTCbits.RC2 = 1;   //  turn off 2nd display unit
PORTD=hexvalue[d];  // send unit place data to 1st digit
PORTCbits.RC3 = 0;  //  turn on 1st display unit
__delay_ms(1);
PORTCbits.RC3 = 1;  //  turn off 1st display unit
      }}
    }}
